'use client';
import Image from "next/image";
import Link from "next/link";
import { signIn, useSession } from "next-auth/react";
// #05b310 green to use for the buttons

// Header Component
function HeadOfPage() {
  const { data: session, status } = useSession();

  const handleSignUpClick = () => {
    signIn("auth0", { callbackUrl: "/home" }); 
  };
  return (
    <div className="header flex flex-row justify-between items-center p-6 bg-black/60 backdrop-blur-lg fixed top-0 w-full z-10 border-b border-white/10 ">
      <Link href="/" className="logo-container flex items-center gap-3 group">
        <Image
          src="/MoneyMentorColors.png"
          alt="Logo"
          className="logo-image transition-transform duration-300 group-hover:scale-110"
          width={50}
          height={50}
        />
        <span className="logo-text text-xl font-bold text-white tracking-tight">
          MoneyMentor
        </span>
      </Link>
      <div className="hidden md:flex items-center space-x-8">
        <Link href="/features" className="text-gray-300 hover:text-white transition-colors">Features</Link>
        <Link href="/about" className="text-gray-300 hover:text-white transition-colors">About</Link>
      </div>
      <div className="flex items-center gap-4">
      {!session ? (
  <>
    <button
      className="text-gray-300 hover:text-white transition-colors hidden md:block bg-transparent border-0 p-0"
      onClick={handleSignUpClick}
    >
      Log In
    </button>
    <button
      className="signup-button bg-gradient-to-r from-blue-500 to-blue-600 text-white px-6 py-2.5 rounded-full shadow-lg hover:shadow-blue-500/25 hover:from-blue-600 hover:to-blue-700 transition-all duration-300 font-medium"
      onClick={handleSignUpClick}
    >
      Sign Up Free
    </button>
  </>
) : (
  <>
      <Link
        href="/home"
        className="text-white/80 hover:text-white font-medium transition-colors hidden md:block"
      >
        Dashboard
      </Link>
      <Link
        href="/budget"
        className="text-white/80 hover:text-white font-medium transition-colors hidden md:block"
      >
        Budget
      </Link>
      <Link
        href="/chatbot"
        className="text-white/80 hover:text-white font-medium transition-colors hidden md:block"
      >
        Chat
      </Link>
  </>
)}
     </div>
    </div>
  );
}

// Hero Section
function Welcome() {
  const { data: session, status } = useSession();
  return (
    <div className="flex flex-col justify-center items-center min-h-screen text-center px-6 relative pt-16">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-green-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob animation-delay-4000"></div>
      </div>

      <div className="relative z-10 max-w-4xl">
        <div className="text-4xl sm:text-6xl font-bold text-white tracking-tight">
          Welcome to
        </div>
        <div className="big-money-mentor min-h-[110px] text-6xl sm:text-8xl font-extrabold bg-gradient-to-r from-blue-400 via-green-400 to-blue-400 text-transparent bg-clip-text mt-4 animate-gradient">
          MoneyMentor
        </div>
        <p className="text-lg sm:text-xl text-gray-300 mt-6 max-w-2xl mx-auto leading-relaxed">
          Your AI-powered financial assistant that helps you create personalized budgets, 
          track expenses, and achieve your financial goals with intelligent insights.
        </p>
        
        <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center items-center">
        {!session ? (
  <>
    <Link href="/home" className="px-8 py-4 bg-gradient-to-r from-blue-500 to-blue-600 text-white text-lg rounded-full shadow-lg hover:shadow-blue-500/25 hover:from-blue-600 hover:to-blue-700 transition-all duration-300 font-medium transform hover:scale-105 w-full sm:w-auto">
            Get Started For Free
          </Link>
  </>
) : (
  <Link href="/home" className="px-8 py-4 bg-gradient-to-r from-blue-500 to-blue-600 text-white text-lg rounded-full shadow-lg hover:shadow-blue-500/25 hover:from-blue-600 hover:to-blue-700 transition-all duration-300 font-medium transform hover:scale-105 w-full sm:w-auto">
            Go to My Dashboard
          </Link>
)}
        </div>
      </div>
    </div>
  );
}

// Features Preview Section
function FeaturesPreview() {
  return (
    <div className="py-24 px-6 relative z-10">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl sm:text-4xl font-bold text-center mb-16">
          <span className="bg-gradient-to-r from-blue-400 to-green-400 text-transparent bg-clip-text">AI-Powered</span> Financial Planning
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Feature 1 */}
          <div className="bg-gray-900/50 backdrop-blur-sm p-8 rounded-2xl border border-white/10 hover:border-blue-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/10 group">
            <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center mb-6 group-hover:bg-blue-500/30 transition-all duration-300">
              <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-3 text-white">Smart Budget Creation</h3>
            <p className="text-gray-400 leading-relaxed">
              Our AI analyzes your income and spending patterns to create a personalized budget that adapts to your lifestyle.
            </p>
          </div>
          
          {/* Feature 2 */}
          <div className="bg-gray-900/50 backdrop-blur-sm p-8 rounded-2xl border border-white/10 hover:border-green-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-green-500/10 group">
            <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center mb-6 group-hover:bg-green-500/30 transition-all duration-300">
              <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-3 text-white">Expense Tracking</h3>
            <p className="text-gray-400 leading-relaxed">
              Automatically categorize your expenses and get real-time insights into your spending habits and patterns.
            </p>
          </div>
          
          {/* Feature 3 */}
          <div className="bg-gray-900/50 backdrop-blur-sm p-8 rounded-2xl border border-white/10 hover:border-purple-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/10 group">
            <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center mb-6 group-hover:bg-purple-500/30 transition-all duration-300">
              <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-3 text-white">Financial Forecasting</h3>
            <p className="text-gray-400 leading-relaxed">
              Predict future expenses and savings with our advanced AI model to help you plan for major financial goals.
            </p>
          </div>
        </div>
        
        <div className="mt-16 text-center">
          <Link href="/features" className="text-blue-400 hover:text-blue-300 flex items-center justify-center gap-2 transition-all duration-300 group">
            <span>Explore all features</span>
            <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </Link>
        </div>
      </div>
    </div>
  );
}

// Footer component
function Footer() {
  return (
    <footer className="bg-black/60 backdrop-blur-lg border-t border-white/10 py-12 px-6">
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
        <div>
          <Link href="/" className="logo-container flex items-center gap-3 mb-4">
            <Image
              src="/MoneyMentorColors.png"
              alt="Logo"
              className="logo-image"
              width={40}
              height={40}
            />
            <span className="logo-text text-lg font-bold text-white tracking-tight">
              MoneyMentor
            </span>
          </Link>
          <p className="text-gray-400 text-sm">
            Your AI-powered financial assistant for smarter budgeting and wealth building.
          </p>
        </div>
        
        <div>
          <h3 className="text-white font-semibold mb-4">Product</h3>
          <ul className="space-y-2">
            <li><Link href="/features" className="text-gray-400 hover:text-white transition-colors text-sm">Features</Link></li>
            <li><Link href="/pricing" className="text-gray-400 hover:text-white transition-colors text-sm">Pricing</Link></li>
            <li><Link href="/faq" className="text-gray-400 hover:text-white transition-colors text-sm">FAQ</Link></li>
          </ul>
        </div>
        
        <div>
          <h3 className="text-white font-semibold mb-4">Company</h3>
          <ul className="space-y-2">
            <li><Link href="/about" className="text-gray-400 hover:text-white transition-colors text-sm">About Us</Link></li>
            <li><Link href="/blog" className="text-gray-400 hover:text-white transition-colors text-sm">Blog</Link></li>
            <li><Link href="/careers" className="text-gray-400 hover:text-white transition-colors text-sm">Careers</Link></li>
            <li><Link href="/contact" className="text-gray-400 hover:text-white transition-colors text-sm">Contact</Link></li>
          </ul>
        </div>
        
        <div>
          <h3 className="text-white font-semibold mb-4">Legal</h3>
          <ul className="space-y-2">
            <li><Link href="/privacy" className="text-gray-400 hover:text-white transition-colors text-sm">Privacy Policy</Link></li>
            <li><Link href="/terms" className="text-gray-400 hover:text-white transition-colors text-sm">Terms of Service</Link></li>
            <li><Link href="/security" className="text-gray-400 hover:text-white transition-colors text-sm">Security</Link></li>
          </ul>
        </div>
      </div>
      
      <div className="mt-12 pt-6 border-t border-white/10 max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center">
        <p className="text-gray-400 text-sm">© 2025 MoneyMentor. All rights reserved.</p>
        <div className="flex space-x-4 mt-4 md:mt-0">
          <Link href="#" className="text-gray-400 hover:text-white transition-colors">
            <span className="sr-only">Twitter</span>
            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
            </svg>
          </Link>
          <Link href="#" className="text-gray-400 hover:text-white transition-colors">
            <span className="sr-only">LinkedIn</span>
            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              <path fillRule="evenodd" d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" clipRule="evenodd" />
            </svg>
          </Link>
        </div>
      </div>
    </footer>
  );
}

// Add styles for animations
const animationStyles = `
  @keyframes blob {
    0% {
      transform: scale(1);
    }
    33% {
      transform: scale(1.2);
    }
    66% {
      transform: scale(0.9);
    }
    100% {
      transform: scale(1);
    }
  }
  
  @keyframes gradient {
    0% {
      background-position: 0% 50%;
    }
    50% {
      background-position: 100% 50%;
    }
    100% {
      background-position: 0% 50%;
    }
  }
  
  .animate-blob {
    animation: blob 7s infinite;
  }
  
  .animate-gradient {
    background-size: 200% 200%;
    animation: gradient 15s ease infinite;
  }
  
  .animation-delay-2000 {
    animation-delay: 2s;
  }
  
  .animation-delay-4000 {
    animation-delay: 4s;
  }
`;

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white">
      <style jsx global>{animationStyles}</style>
      <HeadOfPage />
      <Welcome />
      <FeaturesPreview />
      <Footer />
    </div>
  );
}
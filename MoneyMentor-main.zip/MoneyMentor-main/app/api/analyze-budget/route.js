import { NextResponse } from 'next/server';
import { ChatOllama } from '@langchain/community/chat_models/ollama';

export async function POST(req) {
  try {
    const { email, transactions } = await req.json();

    const model = new ChatOllama({
      baseUrl: 'http://localhost:11434',
      model: 'llama3.1', // or 'mistral', etc.
    });

    const currentMonth = new Date().toLocaleString('default', { month: 'long' });
    const instruction = `
      You are a financial assistant. Your job is to set monthly budgets for users based on their transaction history.
      Analyze the transactions provided and generate a JSON array of budget recommendations for the user. 
      Each recommendation should include the user's email, the month, the category, and the recommended amount.

      Make sure to follow the 50/30/20 rule for budgeting:
      - 50% of income for needs (e.g., rent, groceries, utilities)
      - 30% for wants (e.g., dining out, entertainment, shopping)
      - 20% for savings and debt repayment (e.g., savings account, student loans)
      Ensure that the recommendations are realistic and tailored to the user's spending habits.

      IMPORTANT: The budget for any category must NEVER be less than the total amount spent in that category based on the transactions provided.
      NEVER HAVE NEGATIVE AMOUNTS in the budget recommendations.
      
      Categories should be the same as the ones in the transactions.
      Do not create new categories. Use the categories from the transactions as they are.
      Do not include any other categories.

      Respond ONLY with a JSON array of budget recommendations in the following format:
      [
      {
      "email": "test@example.com",
      "month": "April",
      "category": "Rent",
      "amount": 1200
      },
      {
      "email": "test@example.com",
      "month": "April",
      "category": "Grocery",
      "amount": 300
      }
      ]

      Transactions:
      ${transactions.map(t => `${t.date} - ${t.category} - $${t.amount}`).join('\n')}

      User email: ${email}
      Month: ${currentMonth}
    `;

    const response = await model.invoke(instruction);
    console.log("LLM raw response:", response.content);

    // Try extracting the JSON
    const jsonMatch = response.content.match(/\[.*\]/s);
    if (!jsonMatch) {
      throw new Error("No JSON array found in LLM output.");
    }

    const budgets = JSON.parse(jsonMatch[0]);

    // Ensure all amounts in the budgets are positive
    const positiveBudgets = budgets.map(budget => ({
      ...budget,
      amount: Math.ceil((Math.abs(budget.amount)+100) / 100) * 100, // Round up to nearest 100
    }));

    return NextResponse.json({ budgets: positiveBudgets });
  } catch (err) {
    console.error('[analyze-budget] Error:', err);
    return NextResponse.json(
      { error: 'Failed to analyze and generate budgets', detail: err.message },
      { status: 500 }
    );
  }
}

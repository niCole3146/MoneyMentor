import { NextResponse } from 'next/server';
import clientPromise from '@/app/api/lib/mongodb';
import { ObjectId } from 'mongodb';

export async function POST(request) {
  console.log("----- NEW REQUEST -----");
  console.log("Method:", request.method);
  console.log("URL:", request.url);
  try {
    const data = await request.json();
    console.log("Received data:", data);
    const { email, firstName, accountBalance } = data;

    if (!email || !firstName) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const client = await clientPromise;
    const db = client.db();
    const userData = db.collection('users');

    // Check if user exists first
    const user = await userData.findOne({ email });
    if (user) {
      // If accountBalance is provided, update it
      if (accountBalance !== undefined) {
        await userData.updateOne(
          { email },
          { $set: { accountBalance } }
        );
        user.accountBalance = accountBalance;
      }
      user._id = user._id.toString();
      return NextResponse.json(user, { status: 200 });
    }

    // Initialize monthly_transactions with empty structure
    const monthlyTransactions = {};
    const budget = {}

    // Try to insert new user
    const newUser = {
      email,
      firstName,
      transactions: monthlyTransactions,
      budget: budget,
      accountBalance: accountBalance || 0
    };

    try {
      const result = await userData.insertOne(newUser);
      newUser._id = result.insertedId.toString();
      return NextResponse.json(newUser, { status: 201 });
    } catch (error) {
      // If a duplicate is inserted concurrently, fetch and return the existing user
      if (error.code === 11000) { // Duplicate key error
        const existingUser = await userData.findOne({ email });
        if (existingUser) {
          existingUser._id = existingUser._id.toString();
          return NextResponse.json(existingUser, { status: 200 });
        }
      }
      return NextResponse.json(
        { message: 'User already exists' },
        { status: 200 }
      );
    }
  } catch (error) {
    console.error("Full error:", error);
    console.error('Error in user creation/fetch:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const email = searchParams.get('email');

    if (!email) {
      return NextResponse.json(
        { error: 'Email query parameter is required' },
        { status: 400 }
      );
    }

    const client = await clientPromise;
    const db = client.db();
    const userData = db.collection('users');

    const user = await userData.findOne({ email });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    user._id = user._id.toString();
    return NextResponse.json(user, { status: 200 });
  } catch (error) {
    console.error('Error in user fetch:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 
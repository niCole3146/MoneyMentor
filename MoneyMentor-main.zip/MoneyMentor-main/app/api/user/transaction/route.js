import { NextResponse } from 'next/server';
import clientPromise from '@/app/api/lib/mongodb';

export async function POST(request) {
  try {
    const data = await request.json();
    const { email, month, type, transaction } = data;

    if (!email || !month || !['deposit', 'expense'].includes(type) || !transaction) {
      return NextResponse.json(
        { error: 'Invalid input' },
        { status: 400 }
      );
    }

    const requiredFields = ['category', 'amount', 'date', 'name']; // Added 'name'
    if (!requiredFields.every(field => field in transaction)) {
      return NextResponse.json(
        { error: 'Missing transaction fields' },
        { status: 400 }
      );
    }

    const client = await clientPromise;
    const db = client.db();
    const userData = db.collection('users');

    // Find the user
    const user = await userData.findOne({ email });
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Create transaction object
    const transactionObj = {
      category: transaction.category,
      amount: transaction.amount,
      date: transaction.date,
      name: transaction.name // Added 'name'
    };

    // Determine if it's a deposit or expense
    const mongoField = type === 'deposit' ? 'deposits' : 'expenses';

    // Check if the month exists in the user's transactions
    if (!user.transactions || !user.transactions[month]) {
      // Initialize the month with empty deposits and expenses arrays
      await userData.updateOne(
        { email },
        { 
          $set: { 
            [`transactions.${month}`]: {
              deposits: [],
              expenses: []
            }
          } 
        }
      );
    }

    // Check for duplicate transactions
    const existingTransactions = user.transactions?.[month]?.[mongoField] || [];
    const isDuplicate = existingTransactions.some(existingTransaction =>
      existingTransaction.category === transactionObj.category &&
      existingTransaction.amount === transactionObj.amount &&
      existingTransaction.date === transactionObj.date &&
      existingTransaction.name === transactionObj.name // Check for duplicate 'name'
    );

    if (isDuplicate) {
      return NextResponse.json(
        { error: 'Duplicate transaction detected' },
        { status: 409 } // 409 Conflict
      );
    }

    // Add the transaction to the appropriate array
    await userData.updateOne(
      { email },
      { 
        $push: { 
          [`transactions.${month}.${mongoField}`]: transactionObj 
        } 
      }
    );

    return NextResponse.json(
      { message: 'Transaction added successfully' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Error in transaction addition:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const email = searchParams.get('email');
    const month = searchParams.get('month');
    const type = searchParams.get('type'); // 'deposit' or 'expense'

    // Validate required fields
    if (!email) {
      return NextResponse.json(
        { error: 'Email parameter is required' },
        { status: 400 }
      );
    }

    const client = await clientPromise;
    const db = client.db();
    const userData = db.collection('users');

    // Find the user
    const user = await userData.findOne({ email });
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Prepare response data
    let responseData = {};

    if (month) {
      // Get transactions for specific month
      const monthTransactions = user.transactions?.[month] || {
        deposits: [],
        expenses: []
      };

      if (type) {
        // Handle both singular/plural forms for backward compatibility
        const mongoField = type === 'deposit' ? 'deposits' : 
                          type === 'expense' ? 'expenses' : null;

        if (!mongoField) {
          return NextResponse.json(
            { error: 'Invalid type parameter. Use "deposit" or "expense"' },
            { status: 400 }
          );
        }

        responseData[mongoField] = monthTransactions[mongoField]?.map(transaction => ({
          ...transaction,
          name: transaction.name // Include 'name' in response
        })) || [];
      } else {
        // Return all transaction types for the month
        responseData = {
          deposits: monthTransactions.deposits?.map(transaction => ({
            ...transaction,
            name: transaction.name // Include 'name' in response
          })) || [],
          expenses: monthTransactions.expenses?.map(transaction => ({
            ...transaction,
            name: transaction.name // Include 'name' in response
          })) || []
        };
      }
    } else {
      // Return all transactions organized by month
      responseData = user.transactions || {};
    }

    return NextResponse.json(responseData, { status: 200 });

  } catch (error) {
    console.error('Error fetching transactions:', error);
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    );
  }
}
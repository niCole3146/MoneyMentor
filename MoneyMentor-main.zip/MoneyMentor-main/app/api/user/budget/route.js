import { NextResponse } from 'next/server';
import clientPromise from '@/app/api/lib/mongodb';
import { ObjectId } from 'mongodb';

export async function POST(request) {
  console.log("----- NEW REQUEST -----");
  console.log("Method:", request.method);
  console.log("URL:", request.url);
  try {
    const data = await request.json();
    console.log("Received data:", data);
    const { email, month, budget } = data;

    // Validate required fields (updated to accept an array of budgets)
    if (!email || !month || !budget || !Array.isArray(budget) || budget.length === 0) {
      return NextResponse.json(
        { error: 'Missing required fields (email, month, and a non-empty budget array)' },
        { status: 400 }
      );
    }

    const client = await clientPromise;
    const db = client.db();
    const usersCollection = db.collection('users');

    // Find the user by email
    const user = await usersCollection.findOne({ email });
    
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Replace the entire budget for the month with the new categories
    const updatedBudget = {
      ...user.budget,
      [month]: budget // Replace the month's budget entirely
    };

    // Update the user document with the new budget data
    const result = await usersCollection.updateOne(
      { email },
      { $set: { budget: updatedBudget } }
    );

    return NextResponse.json(
      { message: 'Budget added successfully', budget: updatedBudget },
      { status: 200 }
    );

  } catch (error) {
    console.error("Full error:", error);
    console.error('Error in budget update:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const email = searchParams.get('email');
    const month = searchParams.get('month');

    if (!email) {
      return NextResponse.json(
        { error: 'Email query parameter is required' },
        { status: 400 }
      );
    }

    const client = await clientPromise;
    const db = client.db();
    const usersCollection = db.collection('users');

    const user = await usersCollection.findOne({ email });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Return all budgets if no month specified, or specific month's budgets
    const responseData = month 
      ? { budget: user.budget?.[month] || [] }
      : { budget: user.budget || {} };

    return NextResponse.json(responseData, { status: 200 });
  } catch (error) {
    console.error('Error fetching budget:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
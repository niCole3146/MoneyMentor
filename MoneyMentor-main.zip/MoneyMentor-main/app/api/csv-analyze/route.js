import { NextResponse } from 'next/server';
import { ChatOllama } from '@langchain/community/chat_models/ollama';
import clientPromise from '@/app/api/lib/mongodb';

export async function POST(req) {
  try {
    const { fileContent, email } = await req.json();

    if (!fileContent || !email) {
      return NextResponse.json({ error: 'File content and email are required' }, { status: 400 });
    }

    const model = new ChatOllama({
      baseUrl: 'http://localhost:11434',
      model: 'llama3.1',
    });

    const instruction = `
      You are a financial assistant. Analyze the following CSV data of transactions and generate a single JSON object with two keys:
      1. "transactions": A JSON array of transactions with fields: category, amount, date, and name. The amount should be negative for expenses and positive for deposits.
      2. "budget": A JSON array of budget recommendations with fields: category and amount.

      Amount should never be 0 for any entry

      Budget Categories should be "Groceries", "Rent/Utilities" "Entertainment", "Investing", "Transportation"

      Limit transactios to 5 entries. If transaction is expense, put amount and negative value.
       If transaction is deposit, put amount as positive value.

      Make one of the transactions a deposit called income

      Format should be like this for "transactions":
      [
      {
        "category": "Grocery Shopping",
        "amount": -120.50,
        "date": "2024-03-14", // If no date, use today's date
        "name": "Walmart" // if no name, use "Unknown"
      },
      {
        "category": "Utilities",
        "amount": -100.00,
        "date": "2024-03-15", // if no date, use today's date
        "name": "Electric Company" // if no name, make one up
      }
      ]

      Format for "budget":
      [
      {
        "category": "Grocery Shopping",
        "amount": 1500.00
      },
      {
        "category": "Transportation",
        "amount": 300.00
      }
      ]

      CSV Data:
      ${fileContent}

      Respond ONLY with a JSON object containing two keys: "transactions" and "budget". 
      Do not include any other text or explanation.
      Make sure it's a valid JSON object.
    `;

    const response = await model.invoke(instruction);
    console.log("LLM raw response:", response.content);

    const jsonResponse = JSON.parse(response.content);

    // Parse transactions and budgets correctly
    const transactions = jsonResponse.transactions?.map(t => ({
      category: t.category || "Unknown", // Default to "Unknown" if category is missing
      amount: t.amount || 0, // Default to 0 if amount is missing
      date: t.date || new Date().toISOString().split('T')[0], // Default to today's date if missing
      name: t.name || "Unknown" // Default to "Unknown" if name is missing
    })) || [];

    const budgets = jsonResponse.budget?.map(b => ({
      category: b.category || "Unknown", // Default to "Unknown" if category is missing
      amount: b.amount || 0 // Default to 0 if amount is missing
    })) || [];

    if (!transactions.length || !budgets.length) {
      return NextResponse.json({ error: 'Invalid response from LLM' }, { status: 500 });
    }

    const client = await clientPromise;
    const db = client.db();
    const transactionsCollection = db.collection('transactions');
    const usersCollection = db.collection('users');

    // Group transactions by month
    const groupedTransactions = transactions.reduce((acc, transaction) => {
      const { date, category, amount, name } = transaction;
      const month = new Date(date).toLocaleString('default', { month: 'long' });

      if (!acc[month]) {
        acc[month] = { deposits: [], expenses: [] };
      }

      const type = amount > 0 ? 'deposits' : 'expenses';
      acc[month][type].push({
        category,
        amount,
        date: new Date(date).toISOString().split('T')[0],
        name,
      });

      return acc;
    }, {});

    // Insert or update transactions in MongoDB
    for (const [month, data] of Object.entries(groupedTransactions)) {
      await transactionsCollection.updateOne(
        { email },
        {
          $set: {
            [`transactions.${month}`]: data,
          },
        },
        { upsert: true } // Create the document if it doesn't exist
      );
    }

    // Group transactions into deposits and expenses arrays
    const deposits = [];
    const expenses = [];

    transactions.forEach(transaction => {
      if (transaction.amount > 0) {
        deposits.push(transaction);
      } else {
        expenses.push(transaction);
      }
    });

    // Push deposits into user.transactions.deposits
    await usersCollection.updateOne(
      { email },
      { $push: { 'transactions.deposits': { $each: deposits } } }
    );

    // Push expenses into user.transactions.expenses
    await usersCollection.updateOne(
      { email },
      { $push: { 'transactions.expenses': { $each: expenses } } }
    );

    // Insert budgets into MongoDB for the current month
    const currentMonth = new Date().toLocaleString('default', { month: 'long' });

    if (!email || !Array.isArray(budgets) || budgets.length === 0) {
      return NextResponse.json(
        { error: 'Missing required fields (email and a non-empty budgets array)' },
        { status: 400 }
      );
    }

    const user = await usersCollection.findOne({ email });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Update the budget for the current month
    const userBudget = user.budget || {};

    // Override existing budgets for the current month
    userBudget[currentMonth] = budgets;

    // Update the user document with the new budget data
    await usersCollection.updateOne(
      { email },
      { $set: { budget: userBudget } }
    );

    return NextResponse.json({ message: 'Transactions and budgets created successfully' });
  } catch (err) {
    console.error('[csv-analyze] Error:', err);
    return NextResponse.json(
      { error: 'Failed to analyze CSV and create transactions/budgets', detail: err.message },
      { status: 500 }
    );
  }
}
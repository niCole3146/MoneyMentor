import { getServerSession } from "next-auth/next";
import { NextResponse } from "next/server";

export async function GET(request) {
  const session = await getServerSession();

  if (!session) {
    return new NextResponse(
      JSON.stringify({ error: "You must be logged in." }),
      {
        status: 401,
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
  }

  // Your protected API logic here
  return NextResponse.json({ 
    message: "This is a protected API route",
    user: session.user 
  });
} 
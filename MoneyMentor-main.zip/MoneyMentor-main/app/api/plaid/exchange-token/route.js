import { NextResponse } from 'next/server';
import { exchangePublicToken } from '../../lib/plaid';

export async function POST(request) {
  try {
    const { public_token } = await request.json();
    const accessToken = await exchangePublicToken(public_token);
    return NextResponse.json({ accessToken });
  } catch (error) {
    console.error('Error in exchange-token route:', error);
    return NextResponse.json(
      { error: 'Failed to exchange token' },
      { status: 500 }
    );
  }
} 
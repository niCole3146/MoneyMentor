import { NextResponse } from 'next/server';
import { createLinkToken } from '../../lib/plaid';

export async function POST() {
  try {
    const linkToken = await createLinkToken();
    return NextResponse.json({ linkToken });
  } catch (error) {
    console.error('Error in create-link-token route:', error);
    return NextResponse.json(
      { error: 'Failed to create link token' },
      { status: 500 }
    );
  }
} 
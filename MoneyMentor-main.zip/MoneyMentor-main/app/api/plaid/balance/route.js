import { plaidClient } from '../../lib/plaid';
import { NextResponse } from 'next/server';

export async function POST(req) {
  try {
    const { access_token } = await req.json();

    // Get account balances
    const response = await plaidClient.accountsBalanceGet({
      access_token,
    });

    // Calculate total balance across all accounts
    const totalBalance = response.data.accounts.reduce((sum, account) => {
      return sum + (account.balances.current || 0);
    }, 0);

    return NextResponse.json({ 
      accounts: response.data.accounts,
      totalBalance 
    });
  } catch (error) {
    console.error('Error fetching account balances:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
} 
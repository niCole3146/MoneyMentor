# MoneyMentor API Routes

This directory contains the API routes for the MoneyMentor application. The routes have been migrated from a Flask backend to Next.js API routes.

## MongoDB Connection

The application uses MongoDB as its database. The connection is managed through the `lib/mongodb.js` file, which provides a connection to the MongoDB instance.

## API Endpoints

### User Management

#### Create or Fetch User
- **Endpoint**: `/api/user`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "email": "user@example.com",
    "firstName": "John"
  }
  ```
- **Response**: Returns the user object if it exists, or creates a new user if it doesn't.

#### Get User
- **Endpoint**: `/api/user`
- **Method**: `GET`
- **Query Parameters**:
  - `email`: The email of the user to fetch
- **Response**: Returns the user object if found, or an error if not found.

### Transaction Management

#### Add Transaction
- **Endpoint**: `/api/user/transaction`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "email": "user@example.com",
    "month": "March",
    "type": "expense", // or "deposit"
    "transaction": {
      "category": "Grocery Shopping",
      "amount": -120.50, // negative for expense, positive for deposit
      "date": "2024-03-14"
    }
  }
  ```
- **Response**: Returns a success message if the transaction was added successfully.

#### Get Transaction
- **Endpoint**: `/api/user/transaction`
- **Method**: `GET`
- **Query Parameters**:
  - `email`: The email of the user to fetch
  - `month`: The month of transactions we want to fetch (optional)
  - `type`: The type of transaction we want to fetch: deposit or expense (optional)
- **Response**: Returns the user's specified transaction history if found, or an error if not found.

#### Add Budget
- **Endpoint**: `/api/user/budget`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "email": "test@example.com",
    "month": "March",
    "budget": {
        "category": "Grocery Shopping",
        "amount": 1500.00
    }
  }
  ```
- **Response**: Returns a success message if the budget was added successfully.

#### Get Budget
- **Endpoint**: `/api/user/budget`
- **Method**: `GET`
- **Query Parameters**:
  - `email`: The email of the user to fetch
  - `month`: The month of the budget we want to fetch (optional)
- **Response**: Returns the user's specified budget history if found, or an error if not found.

### Chat Functionality

#### Chat with Financial Assistant
- **Endpoint**: `/api/chat`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "message": "How can I save money on groceries?",
    "sessionId": "unique-session-id"
  }
  ```
- **Response**: Returns a reply from the financial chatbot.
  ```json
  {
    "reply": "Here are some tips to save money on groceries..."
  }
  ```

### Budget Analysis

#### Analyze Budget
- **Endpoint**: `/api/analyze-budget`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "message": "Here is my monthly spending data: [transaction data]"
  }
  ```
- **Response**: Returns financial insights and recommendations.
  ```json
  {
    "reply": "Based on your spending patterns, I recommend..."
  }
  ```

### Authentication

#### NextAuth Authentication
- **Endpoint**: `/api/auth/[...nextauth]`
- **Method**: `GET` and `POST`
- **Description**: Handles authentication using Auth0 provider. This endpoint is managed by NextAuth.js and supports various authentication flows including sign-in, sign-out, and session management.

#### Logout
- **Endpoint**: `/api/auth/logout`
- **Method**: `GET`
- **Description**: Redirects the user to Auth0's logout endpoint to properly terminate their session.

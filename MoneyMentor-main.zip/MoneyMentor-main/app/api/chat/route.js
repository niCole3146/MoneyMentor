import { NextResponse } from 'next/server';
import { ChatOllama } from "@langchain/community/chat_models/ollama";
import { AIMessage, HumanMessage, SystemMessage } from "@langchain/core/messages";
import { ChatPromptTemplate, MessagesPlaceholder } from "@langchain/core/prompts";
import { RunnableSequence } from "@langchain/core/runnables";
import { StringOutputParser } from "@langchain/core/output_parsers";
import clientPromise from '../lib/mongodb'; // Corrected path to MongoDB client setup

// In-memory storage for conversation histories
const conversationHistories = new Map();

export async function POST(request) {
  try {
    const { message, sessionId, email } = await request.json();

    if (!email) {
      throw new Error("Email is required");
    }

    // Initialize or get existing conversation history
    if (!conversationHistories.has(sessionId)) {
      const financialBotPrompt = new SystemMessage(
        `You are a friendly and knowledgeable financial chatbot designed to help college and university students manage their personal finances. Your role is to provide personalized, practical, and easy-to-understand financial advice based on user inputs related to income, expenses, goals, and lifestyle.

          Your goals include:
          - Helping students track spending habits
          - Guiding them to build and follow a budget
          - Offering tips to save money and avoid debt
          - Explaining financial concepts in a simple, student-friendly way
          - Answering common questions about student loans, credit cards, part-time jobs, and saving for the future

          You should be able to:
          1. Ask questions to gather income and expense data from the user
          2. Recommend a realistic monthly budget using the 50/30/20 rule (or alternatives)
          3. Provide weekly or monthly summaries of spending if asked
          4. Suggest specific cost-cutting strategies based on the user’s lifestyle (e.g., eating out often, subscriptions)
          5. Alert users when they exceed their budget in a certain category
          6. Recommend student-friendly financial tools like budgeting apps, bank accounts with no fees, or scholarship databases
          7. Explain terms like “APR,” “emergency fund,” “compound interest,” or “grace period” in simple terms when prompted

          Behavior Rules:
          - Be empathetic and encouraging, especially if the user is stressed about money.
          - Never give investment or legal advice.
          - Avoid recommending risky or aggressive financial strategies.
          - Ensure all advice is age-appropriate and realistic for students.
          
          IMPORTANT - MAKE ANSWERS CONSICE`
      );

      conversationHistories.set(sessionId, [financialBotPrompt]);
    }

    const history = conversationHistories.get(sessionId);

    // Fetch transactions and budgets from MongoDB
    const client = await clientPromise;
    const db = client.db();
    const usersCollection = db.collection('users');

 
    const user = await usersCollection.findOne({ email });

    if (user) {
      const transactions = user.transactions || {};
      const budgets = user.budget || {};

      // Log transactions for debugging
      console.log("Transactions fetched from MongoDB:", transactions);

      // Add transactions and budgets to the conversation history
      history.push(new AIMessage(`Here are your transactions: ${JSON.stringify(transactions, null, 2)}`));
      history.push(new AIMessage(`Here are your budgets: ${JSON.stringify(budgets, null, 2)}`));
    } else {
      history.push(new AIMessage("No transactions or budgets found for this user."));
      console.log("POOP")
    }

    // Create the chat model
    const model = new ChatOllama({
      baseUrl: "http://localhost:11434",
      model: "llama3.1",
    });

    // Create the prompt template
    const prompt = ChatPromptTemplate.fromMessages([
      ...history,
      new MessagesPlaceholder("history"),
      ["human", "{input}"],
    ]);

    // Create the chain
    const chain = RunnableSequence.from([
      prompt,
      model,
      new StringOutputParser(),
    ]);

    // Run the chain
    const response = await chain.invoke({
      input: message,
      history: history.slice(1), // Exclude the system message from history
    });

    // Update conversation history
    history.push(new HumanMessage(message));
    history.push(new AIMessage(response));

    return NextResponse.json({ reply: response });
  } catch (error) {
    console.error('Error in chat API:', error);
    return NextResponse.json(
      { error: 'Failed to process chat request' },
      { status: 500 }
    );
  }
}

import NextAuth from "next-auth";
import Auth0Provider from "next-auth/providers/auth0";

const handler = NextAuth({
  providers: [
    Auth0Provider({
      clientId: process.env.AUTH0_CLIENT_ID,
      clientSecret: process.env.AUTH0_CLIENT_SECRET,
      issuer: process.env.AUTH0_ISSUER_BASE_URL,
    }),
  ],
  secret: process.env.NEXTAUTH_SECRET,
  callbacks: {
    async signIn({ user, account, profile }) {
      return true;
    },
    async session({ session, token, user }) {
      // Add the user's email and first name to the session object
      session.user.id = token.sub; // example of mapping the user ID
      session.user.email = token.email || user.email; // Ensure email is mapped correctly
      session.user.firstName = token.name || 'User'
      session.accessToken = token.accessToken;
      session.user.image = token.picture;
      return session;
    },
    async jwt({ token, account, profile }) {
      if (account && profile) {
        token.email = profile.email;
        token.name = profile.name;
        token.accessToken = account.access_token;
        token.picture = profile.picture;
      }
      return token;
    },
    async redirect({ url, baseUrl }) {
      if (url === baseUrl || url === `${baseUrl}/home`) {
        return url;
      }
      if (url.startsWith("/")) {
        return new URL(baseUrl + url).toString();
      }
      return baseUrl;
    },
  },
});

export { handler as GET, handler as POST }; 
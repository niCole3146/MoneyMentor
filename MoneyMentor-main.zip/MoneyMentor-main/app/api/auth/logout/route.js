import { NextResponse } from 'next/server';

export async function GET() {
  const auth0Domain = process.env.AUTH0_ISSUER_BASE_URL;
  const clientId = process.env.AUTH0_CLIENT_ID;
  const returnTo = process.env.NEXTAUTH_URL || 'http://localhost:3000';

  // Construct Auth0 logout URL
  const auth0LogoutUrl = `${auth0Domain}/v2/logout?client_id=${clientId}&returnTo=${encodeURIComponent(returnTo)}`;
  
  // Redirect to Auth0's logout endpoint
  return NextResponse.redirect(auth0LogoutUrl);
} 
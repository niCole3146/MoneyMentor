"use client";
import Header from "@/components/header-01";
import Footer from "@/components/footer"
import { EnvelopeIcon, PhoneIcon } from "@heroicons/react/24/solid";


function ContactContent() {
    return (
      <div className="min-h-screen px-6 py-24 bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white flex flex-col items-center justify-center">
        <div className="max-w-3xl w-full text-center mt-20">
          <h1 className="text-4xl sm:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-blue-400 to-green-400 text-transparent bg-clip-text">
              Get in Touch
            </span>
          </h1>
          <p className="text-lg text-gray-300 mb-12">
            Whether you have a question, feedback, or just want to say hi — we’d love to hear from you.
          </p>
  
          <div className="flex flex-col sm:flex-row justify-center items-center gap-6">
            {/* Email Button */}
            <a
              href="mailto:support@moneymentor.ai"
              className="inline-flex items-center gap-3 px-6 py-3 bg-[#05b310] text-white rounded-full shadow-lg hover:shadow-green-500/25 hover:bg-green-600 transition-all duration-300 text-lg font-medium"
            >
              <EnvelopeIcon className="w-5 h-5" />
              Email Us
            </a>
  
            {/* Phone Number Display */}
            <div className="inline-flex items-center gap-3 text-gray-300 text-lg">
              <PhoneIcon className="w-5 h-5 text-green-400" />
              <span>(555) 123-4567</span>
            </div>
          </div>
  
          <div className="mt-12 text-sm text-gray-500">
            Our team is available Monday–Friday, 9am–5pm PST.
          </div>
        </div>
      </div>
    );
  }
  
  export default function ContactPage() {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white">
        <Header />
        <ContactContent />
        <Footer />
      </div>
    );
  }
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react'
import Header from '@/components/header-01';
import Footer from "@/components/footer";
import Link from "next/link"

// Budget Overview Component
function BudgetOverview({ userEmail }) {
  const [budgetData, setBudgetData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [totalBudget, setTotalBudget] = useState(0);
  const [totalSpent, setTotalSpent] = useState(0);
  const [accountBalance, setAccountBalance] = useState(0);
  const [recentTransactions, setRecentTransactions] = useState([]);
  const [monthlyTransactions, setMonthlyTransactions] = useState({ expenses: [], deposits: [] });

  useEffect(() => {
    const fetchBudgetData = async () => {
      if (!userEmail) return;
      
      try {
        setLoading(true);
        const currentMonth = new Date().toLocaleDateString('en-US', { month: 'long' });
        
        // Fetch user data for account balance
        const userResponse = await fetch(`/api/user?email=${encodeURIComponent(userEmail)}`);
        if (!userResponse.ok) throw new Error('Failed to fetch user data');
        const userData = await userResponse.json();
        setAccountBalance(userData.accountBalance || 0);
        
        // Fetch budget data
        const budgetResponse = await fetch(`/api/user/budget?email=${encodeURIComponent(userEmail)}&month=${encodeURIComponent(currentMonth)}`);
        if (!budgetResponse.ok) throw new Error('Failed to fetch budget data');
        const budgetData = await budgetResponse.json();
        
        // Fetch transactions for the current month
        const transactionsResponse = await fetch(`/api/user/transaction?email=${encodeURIComponent(userEmail)}&month=${encodeURIComponent(currentMonth)}`);
        if (!transactionsResponse.ok) throw new Error('Failed to fetch transactions');
        const transactionsData = await transactionsResponse.json();
        
        // Calculate total budget and spending
        const totalBudget = budgetData.budget.reduce((sum, item) => sum + item.amount, 0);
        const totalSpent = (transactionsData.expenses || []).reduce((sum, expense) => sum + Math.abs(expense.amount), 0);
        
        // Get recent transactions (last 5)
        const allTransactions = [
          ...(transactionsData.deposits || []).map(t => ({ ...t, type: 'deposit' })),
          ...(transactionsData.expenses || []).map(t => ({ ...t, type: 'expense' }))
        ].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5);
        
        setBudgetData(budgetData.budget);
        setTotalBudget(totalBudget);
        setTotalSpent(totalSpent);
        setRecentTransactions(allTransactions);
        setMonthlyTransactions({
          expenses: transactionsData.expenses || [],
          deposits: transactionsData.deposits || []
        });
      } catch (err) {
        console.error('Error fetching budget data:', err);
        setError('Failed to load budget data');
      } finally {
        setLoading(false);
      }
    };

    fetchBudgetData();
  }, [userEmail]);

  // Calculate spending for a specific category
  const calculateCategorySpending = (category) => {
    if (category === 'Monthly') {
      return monthlyTransactions.expenses.reduce((sum, expense) => sum + Math.abs(expense.amount), 0);
    }
    return monthlyTransactions.expenses
      .filter(expense => expense.category === category)
      .reduce((sum, expense) => sum + Math.abs(expense.amount), 0);
  };

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
        <div className="bg-gray-800/50 backdrop-blur-sm p-6 rounded-xl border border-white/10">
          <div className="h-8 bg-gray-700/30 rounded animate-pulse"></div>
        </div>
        <div className="bg-gray-800/50 backdrop-blur-sm p-6 rounded-xl border border-white/10">
          <div className="h-8 bg-gray-700/30 rounded animate-pulse"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-gray-800/50 backdrop-blur-sm p-6 rounded-xl border border-white/10 m-6">
        <p className="text-red-400">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Monthly Budget Summary */}
      <div className="bg-gray-800/50 backdrop-blur-sm p-8 rounded-xl border border-white/10 mb-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M4 4a2 2 0 00-2 2v4a2 2 0 002 2V6h10a2 2 0 00-2-2H4zm2 6a2 2 0 012-2h8a2 2 0 012 2v4a2 2 0 01-2 2H8a2 2 0 01-2-2v-4zm6 4a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
            </svg>
          </div>
          <div>
            <h2 className="text-xl font-semibold text-white">Monthly Budget Summary</h2>
            <p className="text-gray-400 text-sm">Overview of your spending</p>
          </div>
        </div>

        {/* Monthly Budget Progress */}
        <div className="space-y-6">
          <div className="relative">
            <div className="flex justify-between items-center mb-2">
              <p className="text-gray-400 text-sm">Monthly Budget</p>
              <p className="text-white font-semibold">${totalBudget.toFixed(2)}</p>
            </div>
            <div className="relative h-6 bg-gray-700/30 rounded-full overflow-hidden">
              {/* Spent Amount */}
              <div 
                className="absolute h-full bg-blue-500 transition-all duration-500 rounded-full"
                style={{ width: `${Math.min((totalSpent / totalBudget) * 100, 100)}%` }}
              ></div>
              {/* Remaining Amount */}
              <div 
                className="absolute h-full bg-gray-600/30 transition-all duration-500"
                style={{ 
                  width: `${Math.max(100 - (totalSpent / totalBudget) * 100, 0)}%`,
                  left: `${Math.min((totalSpent / totalBudget) * 100, 100)}%`
                }}
              ></div>
            </div>
            <div className="flex justify-between items-center mt-2">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                <div>
                  <p className="text-gray-400 text-sm">Spent</p>
                  <p className="text-white font-semibold">${totalSpent.toFixed(2)}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-gray-600/30"></div>
                <div className="text-right">
                  <p className="text-gray-400 text-sm">Remaining</p>
                  <p className="text-white font-semibold">${(totalBudget - totalSpent).toFixed(2)}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Budget Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {budgetData.map((category, index) => {
          const spent = calculateCategorySpending(category.category);
          const percentage = (spent / category.amount) * 100;
          const remaining = category.amount - spent;
          const remainingPercentage = (remaining / category.amount) * 100;
          
          return (
            <div key={index} className="bg-gray-800/50 backdrop-blur-sm p-8 rounded-xl border border-white/10">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M4 4a2 2 0 00-2 2v4a2 2 0 002 2V6h10a2 2 0 00-2-2H4zm2 6a2 2 0 012-2h8a2 2 0 012 2v4a2 2 0 01-2 2H8a2 2 0 01-2-2v-4zm6 4a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-white">{category.category}</h3>
                    <p className="text-gray-400 text-sm">Budget category</p>
                  </div>
                </div>
                <p className="text-2xl font-bold text-white">${category.amount.toFixed(2)}</p>
              </div>

              <div className="space-y-4">
                {/* Budget Progress Bar */}
                <div className="relative h-4 bg-gray-700/30 rounded-full overflow-hidden">
                  {/* Spent Amount */}
                  <div 
                    className="absolute h-full bg-blue-500 transition-all duration-500 rounded-full"
                    style={{ width: `${Math.min(percentage, 100)}%` }}
                  ></div>
                  {/* Remaining Amount */}
                  <div 
                    className="absolute h-full bg-gray-600/30 transition-all duration-500"
                    style={{ 
                      width: `${remainingPercentage}%`,
                      left: `${Math.min(percentage, 100)}%`
                    }}
                  ></div>
                </div>

                {/* Amount Labels */}
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                    <div>
                      <p className="text-gray-400 text-sm">Spent</p>
                      <p className="text-white font-semibold">${spent.toFixed(2)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-gray-600/30"></div>
                    <div className="text-right">
                      <p className="text-gray-400 text-sm">Remaining</p>
                      <p className="text-white font-semibold">${remaining.toFixed(2)}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Section: Account Balance and Recent Activity */}
      <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl border border-white/10 overflow-hidden mt-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-0">
          {/* Account Balance Card */}
          <div className="md:col-span-3 bg-gradient-to-br from-blue-600/20 to-purple-600/20 p-8 border-b md:border-b-0 md:border-r border-white/10">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" />
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z" clipRule="evenodd" />
                </svg>
              </div>
              <div>
                <h2 className="text-xl font-semibold text-white">Account Balance</h2>
                <p className="text-gray-400 text-sm">Current available funds</p>
              </div>
            </div>
            <p className="text-4xl font-bold text-white">${accountBalance.toFixed(2)}</p>
          </div>

          {/* Recent Activity */}
          <div className="md:col-span-9 p-8">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 2a8 8 0 100 16 8 8 0 000-16zm0 14a6 6 0 110-12 6 6 0 010 12zm-1-5a1 1 0 011-1h2a1 1 0 110 2h-2a1 1 0 01-1-1zm0-4a1 1 0 011-1h2a1 1 0 110 2h-2a1 1 0 01-1-1z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-white">Recent Activity</h2>
                  <p className="text-gray-400 text-sm">Latest transactions</p>
                </div>
              </div>
              <Link
                href="/transactions"
                className="text-blue-400 hover:text-blue-300 text-sm transition-colors"
              >
                View All →
              </Link>
            </div>

            <div className="space-y-4">
              {recentTransactions.length > 0 ? (
                recentTransactions.map((transaction, index) => (
                  <div 
                    key={index} 
                    className={`group flex items-center justify-between p-4 rounded-lg transition-all duration-200 ${
                      transaction.type === 'deposit' 
                        ? 'bg-green-500/5 hover:bg-green-500/10' 
                        : 'bg-red-500/5 hover:bg-red-500/10'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        transaction.type === 'deposit' 
                          ? 'bg-green-500/20 text-green-400' 
                          : 'bg-red-500/20 text-red-400'
                      }`}>
                        {transaction.type === 'deposit' ? (
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v3.586L7.707 9.293a1 1 0 00-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 10.586V7z" clipRule="evenodd" />
                          </svg>
                        ) : (
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v3.586L7.707 9.293a1 1 0 00-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 10.586V7z" clipRule="evenodd" transform="rotate(180 10 10)" />
                          </svg>
                        )}
                      </div>
                      <div>
                        <p className="text-white font-medium text-base group-hover:text-white/80 transition-colors">
                          {transaction.name || 'Unnamed Transaction'}
                        </p>
                        <div className="flex items-center gap-2 text-sm text-gray-400">
                          <span>{transaction.category}</span>
                          <span>•</span>
                          <span>{new Date(transaction.date).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>
                    <p className={`font-semibold text-base ${
                      transaction.type === 'deposit' ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {transaction.type === 'deposit' ? '+' : '-'}${Math.abs(transaction.amount).toFixed(2)}
                    </p>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-white/10 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <p className="text-gray-400 text-base">No recent transactions</p>
                  <p className="text-gray-500 text-sm mt-2">Your transactions will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  const { data: session, status } = useSession();

  const [firstName, setFirstName] = useState('User');
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (status === 'authenticated' && session) {
      const userPayload = {
        firstName: session.user.given_name || session.user.name || 'User',
        email: session.user.email,
      };

      fetch('http://localhost:3000/api/user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userPayload),
      })
        .then((res) => {
          if (!res.ok) {
            throw new Error('Network response was not ok');
          }
          return res.json();
        })
        .then((data) => {
          setFirstName(data.firstName || userPayload.firstName);
          setLoadingData(false);
        })
        .catch((error) => {
          console.error('Error fetching user data:', error);
          setLoadingData(false);
        });
    } else {
      setLoadingData(false);
    }
  }, [session, status]);

  if (status === 'loading' || loadingData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
        <p className="text-white text-xl">Loading...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white">
      <Header 
        userName={firstName || "User"}
        userImage={session?.user?.image}
      />

      <main className="pt-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-4xl font-bold">Welcome, {firstName}!</h1>
            <Link
              href="/budget"
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors"
            >
              Manage Budget
            </Link>
          </div>

          <BudgetOverview userEmail={session?.user?.email} />
          <Footer />
        </div>
      </main>
    </div>
  );
}
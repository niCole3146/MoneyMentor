"use client";
import React from "react";
import Image from "next/image";
import Link from "next/link";
import Header from "@/components/header-01";
import Footer from "@/components/footer"

const teamMembers = [
  {
    name: "Jonny Grenillo",
    role: "role",
    image: "/MoneyMentorColors.png",
  },
  {
    name: "LaNaysha Simms",
    role: "role",
    image: "/MoneyMentorColors.png",
  },
  {
    name: "Ethan Gould",
    role: "role",
    image: "/MoneyMentorColors.png",
  },
  {
    name: "NaveenJohn Premkumar",
    role: "role",
    image: "/MoneyMentorColors.png",
  },
  {
    name: "Cole Doyle",
    role: "role",
    image: "/MoneyMentorColors.png",
  },
  {
    name: "Jobin Babu",
    role: "role",
    image: "/MoneyMentorColors.png",
  },
  {
    name: "Rohan Shetty",
    role: "role",
    image: "/MoneyMentorColors.png",
  },
];

const AboutUs = () => {
  return (
    <div className="min-h-screen px-6 py-24 bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-4xl sm:text-5xl font-bold text-center mb-10">
          <span className="bg-gradient-to-r from-blue-400 to-green-400 text-transparent bg-clip-text">About Us</span>
        </h1>

        <section className="text-center mb-16">
          <p className="text-lg sm:text-xl text-gray-300 leading-relaxed max-w-3xl mx-auto">
            Welcome to our company! We’re driven by innovation and committed to creating meaningful financial solutions.
          </p>
          <p className="text-lg sm:text-xl text-gray-400 mt-4 leading-relaxed max-w-3xl mx-auto">
            From humble beginnings to a growing movement, our mission has always been clear: empower people with smart, accessible tools that make financial freedom achievable.
          </p>
        </section>

        <section className="mt-16">
          <h2 className="text-3xl sm:text-4xl font-semibold text-center mb-12">
            Meet Our Team
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-10 justify-items-center">
            {teamMembers.map((member, index) => (
              <div
                key={index}
                className="bg-gray-900/50 border border-white/10 backdrop-blur-lg rounded-xl p-6 shadow-lg hover:shadow-green-500/10 transition-all duration-300 text-center w-64"
              >
                <Image
                  src={member.image}
                  alt={member.name}
                  width={120}
                  height={120}
                  className="rounded-full mx-auto mb-4 border-4 border-green-500/30"
                />
                <h3 className="text-xl font-bold text-white">{member.name}</h3>
                <p className="text-sm text-gray-400 mt-1">{member.role}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-20 text-center">
          <Link
            href="/contact"
            className="px-8 py-4 bg-[#05b310] text-white text-lg rounded-full shadow-lg hover:shadow-green-500/25 hover:bg-green-600 transition-all duration-300 font-medium transform hover:scale-105 inline-block"
          >
            Contact Us
          </Link>
        </section>
      </div>
    </div>
  );
};

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white">
      <Header />
      <AboutUs />
      <Footer />
    </div>
  );
}
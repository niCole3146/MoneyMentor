"use client";
import { useState, useEffect, useRef } from "react";
import { Send, Upload } from "lucide-react";
import Footer from "@/components/footer"
import Header from "@/components/header-01";
import { useSession } from "next-auth/react";
import ReactMarkdown from 'react-markdown';

export default function ChatbotUI() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [hasReplied, setHasReplied] = useState(false);
  const [csvData, setCsvData] = useState(null);
  const [isWelcomeVisible, setIsWelcomeVisible] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const sessionId = useRef(Date.now().toString());
  const { data: session } = useSession();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    setIsWelcomeVisible(false);
    setMessages((prevMessages) => [...prevMessages, { text: input, sender: "user" }]);
    setInput("");
    setHasReplied(true);
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          message: input,
          sessionId: sessionId.current,
          email: session?.user?.email || null,
        }),
      });

      const data = await response.json();

      setMessages((prevMessages) => [
        ...prevMessages,
        { text: data.reply, sender: "bot" }
      ]);
    } catch (error) {
      console.error('Error:', error);
      setMessages((prevMessages) => [
        ...prevMessages,
        { text: "Sorry, something went wrong. Please try again later.", sender: "bot" }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      handleSend();
    }
  };

  return (
    <div className="relative h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 overflow-hidden">
      <Header userName={session?.user?.given_name || session?.user?.name || 'User'} userImage={session?.user?.image || '/default-profile-pic.jpg'}/>

      <div className="flex flex-col h-full pt-24">
        {/* Message Container */}
        <div className="flex-1 relative overflow-auto px-4 pb-4">
          {/* Welcome Centered */}
          {isWelcomeVisible && messages.length === 0 && (
            <div className="absolute inset-0 flex justify-center items-center z-0">
              <div className="p-8 text-lg text-white/80 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 shadow-lg max-w-md text-center">
                <h2 className="text-2xl font-bold text-white mb-4">Welcome to MoneyMentor AI</h2>
                <p className="text-white/60">How can I help you with your finances today?</p>
              </div>
            </div>
          )}

          {/* Actual Messages */}
          <div className="space-y-4 relative z-10">
            {messages.map((msg, index) => (
              <div
                key={index}
                className={`w-fit max-w-2xl p-4 rounded-xl shadow-lg backdrop-blur-sm transform transition-all duration-300 ease-out animate-slide-in
                  ${msg.sender === "user" 
                    ? "ml-auto bg-blue-500/90 text-white" 
                    : "bg-gray-700/90 border border-gray-600 text-white"}`}
              >
                {msg.sender === "bot" ? (
                  <div className="prose prose-invert max-w-none">
                    <ReactMarkdown
                      components={{
                        p: ({ children }) => <p className="mb-4">{children}</p>,
                        ul: ({ children }) => <ul className="list-disc pl-4 mb-4">{children}</ul>,
                        ol: ({ children }) => <ol className="list-decimal pl-4 mb-4">{children}</ol>,
                        li: ({ children }) => <li className="mb-1">{children}</li>,
                        code: ({ children }) => (
                          <code className="bg-gray-800/50 px-2 py-1 rounded text-sm font-mono">
                            {children}
                          </code>
                        ),
                        pre: ({ children }) => (
                          <pre className="bg-gray-800/50 p-4 rounded-lg overflow-x-auto my-4">
                            {children}
                          </pre>
                        ),
                      }}
                    >
                      {msg.text}
                    </ReactMarkdown>
                  </div>
                ) : (
                  msg.text
                )}
              </div>
            ))}

            {isLoading && (
              <div className="w-fit max-w-md p-4 rounded-xl shadow-lg backdrop-blur-sm bg-gray-700/90 border border-gray-600 text-white animate-pulse">
                Thinking...
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Fixed Input Bar */}
        <div className="sticky bottom-0 left-0 right-0 bg-black/30 backdrop-blur-sm border-t border-white/10 px-4 py-4 z-20">
          <div className="flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a message..."
              className="flex-1 px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 text-white placeholder-white/40 outline-none transition-all"
            />

            <button 
              onClick={handleSend} 
              className="p-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl transition-colors"
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
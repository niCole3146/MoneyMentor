'use client';

import { useSearchParams, useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import Grid from '@/components/grid';
import Header from '@/components/header-01';
import Footer from '@/components/footer';
import { useSession } from "next-auth/react"; 

export default function BudgetPage() {
  const params = useParams();
  console.log("Params:", params);
  const searchParams = useSearchParams();
  const mode = searchParams.get('mode'); // "upload" or "manual" for now
  const decodedBudgetID = decodeURIComponent(params.budgetID);
  const [month, year] =decodedBudgetID.split(' ');

  const [budgetData, setBudgetData] = useState(null);
  const { data: session } = useSession();


  return (

    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white">
      <Header userName={session?.user?.given_name || session?.user?.name || 'User'} userImage={session?.user?.image || '/default-profile-pic.jpg'}/>
      <div className="pt-20 px-6">
        <h1 className="text-2xl mb-4">
          {month} {year} Budget: 
        </h1>

        <Grid />
      </div>
      <Footer />
</div>
  );
}

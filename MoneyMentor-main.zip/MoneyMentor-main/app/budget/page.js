'use client';

import { useState, useEffect } from 'react';
import Header from '@/components/header-01';
import Footer from "@/components/footer"
import { useSession } from 'next-auth/react'
import PlaidLink from '@/components/PlaidLink';
import BudgetGrid from '@/components/BudgetGrid';
import Grid from '@/components/grid';
import Papa from 'papaparse'
import { useRouter } from 'next/navigation';

// Import Options Component
function ImportOptions() {
  const [selectedOption, setSelectedOption] = useState(null);
  const [plaidConnected, setPlaidConnected] = useState(false);
  const { data: session } = useSession();
  const [csvData, setCsvData] = useState(null);
  const [messages, setMessages] = useState([]);

  const router = useRouter(); // Use router only after mounting

  // Function to handle file upload and CSV parsing
  const handleCSVUpload = async (event) => {
    const file = event.target.files[0];

    if (file && file.type === "text/csv") {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const text = e.target.result;

        try {
          const response = await fetch('/api/csv-analyze', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ fileContent: text, email: session?.user?.email }),
          });

          if (!response.ok) {
            console.error('Error analyzing CSV:', await response.text());
          } else {
            console.log('CSV analysis completed successfully!');
          }
        } catch (error) {
          console.error('Error:', error);
        }
      };
      reader.readAsText(file);
    } else {
      alert("Please upload a valid CSV file.");
    }
  };

  // Function for manual mode
  const handleManualInput = async () => {
    // Get current month and year in "Month YYYY" format
    const date = new Date();
    const options = { year: 'numeric', month: 'long' };
    const monthId = date.toLocaleDateString('en-US', options); // e.g. "April 2025"
  
    const budgetData = {
      email: session.user.email,
      month: monthId,
      budget: [
        { category: "Category", amount: 500 }, // placeholder
        {category: "Expense", amount: 500},
      ]
    };
  
    try {
      console.log("Sending budgetData:", budgetData);
      const res = await fetch("/api/user/budget", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(budgetData)
      });
  
      if (!res.ok) {
        const errorData = await res.json(); // Get error details from the response
        console.error("Error details:", errorData.error || errorData.message || "Unknown error");
        throw new Error("Failed to create budget");
      }
  
      // Navigate to the new budget page
      router.push(`/budget/${encodeURIComponent(monthId)}`);
    } catch (err) {
      console.error("Error creating budget:", err);
    }
  };


  const handlePlaidSuccess = async (accessToken, metadata) => {
    setPlaidConnected(true);
    console.log('Plaid connected successfully:', { accessToken, metadata });

    try {
      // First, fetch account balances
      const balanceRes = await fetch('/api/plaid/balance', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ access_token: accessToken }),
      });

      const balanceData = await balanceRes.json();

      if (balanceData.totalBalance !== undefined) {
        // Update user's account balance
        const userEmail = session?.user?.email || 'unknown@example.com';
        await fetch('/api/user', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            email: userEmail,
            firstName: session?.user?.given_name || session?.user?.name || 'User',
            accountBalance: balanceData.totalBalance
          }),
        });
      }

      // Then fetch transactions as before
      const res = await fetch('/api/plaid/transactions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ access_token: accessToken }),
      });

      const data = await res.json();

      if (data.transactions) {
        console.log('Fetched Transactions:', data.transactions);

        // Update MongoDB with fetched transactions
        try {
          const userEmail = session?.user?.email || 'unknown@example.com';

          const transactions = data.transactions.map(transaction => ({
            category: transaction.category?.[0] || 'Uncategorized',
            amount: transaction.amount,
            date: transaction.date,
            name: transaction.name
          }));

          // Send all transactions to MongoDB
          const updatePromises = transactions.map(async (transaction) => {
            const payload = {
              email: userEmail,
              month: new Date().toLocaleString('default', { month: 'long' }),
              type: 'expense',
              transaction: {
                category: transaction.category,
                amount: -Math.abs(transaction.amount), // Ensure expense amounts are negative
                date: transaction.date,
                name: transaction.name
              }
            };

            console.log('Sending transaction to /api/user/transaction:', payload);

            const updateRes = await fetch('/api/user/transaction', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(payload),
            });

            const updateData = await updateRes.json();

            if (!updateRes.ok) {
              console.error('Failed to update transaction in MongoDB:', updateData);
            } else {
              console.log('Transaction updated in MongoDB:', updateData);
            }
          });

          await Promise.all(updatePromises);
          console.log('All transactions updated in MongoDB successfully!');

          // Continue with budget analysis as before...
          try {
            const aiRes = await fetch('/api/analyze-budget', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                email: userEmail,
                transactions: transactions,
              }),
            });

            const aiData = await aiRes.json();

            if (!aiRes.ok) {
              console.error('LLM failed to generate budget:', aiData.error || aiData);
            } else {
              const recommendedBudgets = aiData.budgets || [];
              console.log('Recommended budgets from LLM:', recommendedBudgets);
              
              const month = new Date().toLocaleString('default', { month: 'long' });
              
              const budgetArray = recommendedBudgets.map(budget => ({
                category: budget.category,
                amount: budget.amount,
              }));

              const budgetUpdatePromises = recommendedBudgets.map(async (budget) => {
                const res = await fetch('/api/user/budget', {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                  },
                  body: JSON.stringify({
                    email: budget.email,
                    month: budget.month || month,
                    budget: budgetArray,
                  }),
                });

                const result = await res.json();

                if (!res.ok) {
                  console.error('Failed to save budget:', result);
                } else {
                  console.log('Saved budget:', result);
                }
              });
            
              await Promise.all(budgetUpdatePromises);
              // alert('Budgets have been automatically set and saved to MongoDB!');
            }
          } catch (llmError) {
            console.error('Error calling analyze-budget endpoint:', llmError);
          }
        } catch (updateError) {
          console.error('Error updating transactions in MongoDB:', updateError);
        }
      } else {
        console.error('No transactions returned:', data);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold text-white mb-4">Set Up Your Budget</h1>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Choose how you'd like to import your financial data to get started with your personalized budget.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {/* CSV Upload Option */}
        <div 
          className={`p-6 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
            selectedOption === 'csv' 
              ? 'border-blue-500 bg-blue-500/10' 
              : 'border-white/10 hover:border-blue-500/50'
          }`}
          onClick={() => setSelectedOption('csv')}
        >
          <div className="flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Upload Spreadsheet</h3>
            <p className="text-gray-400 text-sm mb-4">
              Import your budget data from a spreadsheet
            </p>
            <button className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
              Choose File
            </button>
          </div>
        </div>

        {/* Plaid Connection Option */}
        <div 
          className={`p-6 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
            selectedOption === 'plaid' 
              ? 'border-green-500 bg-green-500/10' 
              : 'border-white/10 hover:border-green-500/50'
          }`}
          onClick={() => setSelectedOption('plaid')}
        >
          <div className="flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Connect with Plaid</h3>
            <p className="text-gray-400 text-sm mb-4">
              Securely connect your bank accounts for automatic updates
            </p>
            <PlaidLink onSuccess={handlePlaidSuccess} />
          </div>
        </div>

        {/* Manual Input Option */}
        <div 
          className={`p-6 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
            selectedOption === 'manual' 
              ? 'border-purple-500 bg-purple-500/10' 
              : 'border-white/10 hover:border-purple-500/50'
          }`}
          onClick={() => setSelectedOption('manual')}
        >
          <div className="flex flex-col items-center text-center">
            <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Manual Input</h3>
            <p className="text-gray-400 text-sm mb-4">
              Enter your financial data manually
            </p>
            <button className="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors">
              Start Input
            </button>
          </div>
        </div>
      </div>

      {/* Selected Option Details */}
      {selectedOption && (
        <div className="mt-8 max-w-2xl mx-auto p-6 bg-gray-800/50 rounded-xl border border-white/10">
          <h2 className="text-xl font-bold text-white mb-4">
            {selectedOption === 'csv' && 'Upload Spreadsheet'}
            {selectedOption === 'plaid' && 'Connect with Plaid'}
            {selectedOption === 'manual' && 'Manual Input'}
          </h2>
          <div className="space-y-4">
            {selectedOption === 'csv' && (
              <div>
                <p className="text-gray-400 mb-4">
                  Upload your spreadsheet with the following columns:
                </p>
                <ul className="list-disc list-inside text-gray-400 space-y-2">
                  <li>Date</li>
                  <li>Description</li>
                  <li>Amount</li>
                  <li>Category</li>
                </ul>
                <div className="mt-6">
                  <input type="file" accept=".csv" className="hidden" id="csv-upload" onChange={handleCSVUpload}/>
                  <label htmlFor="csv-upload" className="inline-block px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors cursor-pointer">
                    Select Spreadsheet
                  </label>
                </div>
              </div>
            )}

            {selectedOption === 'plaid' && (
              <div>
                <p className="text-gray-400 mb-4">
                  {plaidConnected 
                    ? "Your bank account has been successfully connected! You can now view your transactions and budget."
                    : "Connect your bank accounts securely through Plaid. We'll automatically import your transactions and keep your budget up to date."}
                </p>
                {!plaidConnected && <PlaidLink onSuccess={handlePlaidSuccess} />}
              </div>
            )}

            {selectedOption === 'manual' && (
              <div>
                <p className="text-gray-400 mb-4">
                  Enter your financial information manually. We'll guide you through the process step by step.
                </p>
                <button className="px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors" onClick={handleManualInput}>
                  Start Manual Entry
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}


function BudgetPage() {
  const { data: session, status } = useSession();
  const [budget, setBudget] = useState([]);
  const [month, setMonth] = useState(new Date().toLocaleDateString('en-US', { month: 'long' })); // dynamic month
  const [isLoading, setIsLoading] = useState(true); // Track loading state

  useEffect(() => {
    if (!session?.user?.email) return;

    const fetchBudgets = async () => {
      try {
        const res = await fetch(`/api/user/budget?email=${session.user.email}&month=${month}`);
        const data = await res.json();
        console.log('Fetched budgets data:', data); // Log the fetched data
        setBudget(data.budget);
        setIsLoading(false); // Mark loading as complete after fetching
      } catch (err) {
        console.error('Failed to fetch budget categories:', err);
        setIsLoading(false); // Mark loading as complete on error too
      }
    };

    fetchBudgets();
  }, [session, month]);

  if (status === 'loading' || isLoading) {
    return <div className="text-white p-6">Loading your data...</div>;
  }

  if (!session) {
    return <div className="text-white p-6">Please log in to view your budget.</div>;
  }

  return (
    <div className="p-6">
      <h1 className="text-white text-2xl font-bold mb-6">
        Budget Summary for {month}
      </h1>
      <div className="mb-6 flex items-center space-x-4">
        <label htmlFor="month-select" className="text-white text-lg">Search Past Budgets:</label>
        <div className="relative">
          <select
            id="month-select"
            value={month}
            onChange={(e) => setMonth(e.target.value)}
            style={{
              backgroundColor: '#1f2937',
              color: 'white',
              padding: '0.5rem 1.5rem 0.5rem 0.75rem',
              borderRadius: '0.5rem',
              border: '1px solid #4b5563',
              cursor: 'pointer',
              minWidth: '120px',
              width: '120px',
              appearance: 'none',
              WebkitAppearance: 'none',
              MozAppearance: 'none',
              fontSize: '0.95rem',
              fontWeight: '500',
              transition: 'all 0.2s ease-in-out',
              boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)'
            }}
            onMouseEnter={(e) => {
              e.target.style.backgroundColor = '#374151';
              e.target.style.borderColor = '#6b7280';
            }}
            onMouseLeave={(e) => {
              e.target.style.backgroundColor = '#1f2937';
              e.target.style.borderColor = '#4b5563';
            }}
          >
            {Array.from({ length: 12 }, (_, i) => {
              const date = new Date();
              date.setMonth(i);
              return date.toLocaleString('en-US', { month: 'long' });
            }).map((monthName) => (
              <option 
                key={monthName} 
                value={monthName}
                style={{
                  backgroundColor: '#1f2937',
                  color: 'white',
                  padding: '0.5rem',
                  fontSize: '0.95rem',
                  fontWeight: '500'
                }}
              >
                {monthName}
              </option>
            ))}
          </select>
          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400 -translate-y-1/2 top-1/2 -translate-x-1/2">
            <span className="text-sm">▼</span>
          </div>
        </div>
      </div>
      <BudgetGrid budget={budget} />
    </div>
  );
}


export default function Budget() {
  const { data: session } = useSession();
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white">
      <Header 
        userName={session?.user?.given_name || session?.user?.name || 'User'}
        userImage={session?.user?.image || '/default-profile-pic.jpg'}
        showDashboard={true}
      />
      <main className="pt-24 px-6">
        <div className="max-w-7xl mx-auto">
          <ImportOptions />
          <BudgetPage />
        </div>
      </main>
      <Footer />
    </div>
  );
}
"use client";
import { BoltIcon, ChartBarIcon, CurrencyDollarIcon } from "@heroicons/react/24/solid";
import Header from '@/components/header-01';
import Footer from "@/components/footer";

function FeaturesContent() {
  return (
    <div className="min-h-screen px-6 py-24 bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white flex flex-col items-center">
      <div className="max-w-5xl w-full mt-20 text-center">
        <h1 className="text-4xl sm:text-5xl font-bold mb-6">
          <span className="bg-gradient-to-r from-blue-400 to-green-400 text-transparent bg-clip-text">
            Features That Power Your Finances
          </span>
        </h1>
        <p className="text-lg text-gray-300 mb-16">
          Take control of your money with cutting-edge tools designed for simplicity, clarity, and results.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Feature 1: Smart Budgeting */}
          <div className="bg-gray-900/50 backdrop-blur-sm p-8 rounded-2xl border border-white/10 hover:border-blue-500/50 hover:shadow-blue-500/10 transition-all duration-300 hover:shadow-lg group">
            <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center mb-6 group-hover:bg-blue-500/30">
              <BoltIcon className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-xl font-bold mb-3 text-white">Smart Budget Creation</h3>
            <p className="text-gray-400 leading-relaxed">
              AI analyzes your income and spending to auto-generate a personalized budget that adapts over time.
            </p>
          </div>

          {/* Feature 2: Expense Tracking */}
          <div className="bg-gray-900/50 backdrop-blur-sm p-8 rounded-2xl border border-white/10 hover:border-green-500/50 hover:shadow-green-500/10 transition-all duration-300 hover:shadow-lg group">
            <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center mb-6 group-hover:bg-green-500/30">
              <ChartBarIcon className="w-6 h-6 text-green-400" />
            </div>
            <h3 className="text-xl font-bold mb-3 text-white">Real-Time Expense Tracking</h3>
            <p className="text-gray-400 leading-relaxed">
              Categorize spending instantly. Get insights and alerts when you're going over budget.
            </p>
          </div>

          {/* Feature 3: Forecasting */}
          <div className="bg-gray-900/50 backdrop-blur-sm p-8 rounded-2xl border border-white/10 hover:border-purple-500/50 hover:shadow-purple-500/10 transition-all duration-300 hover:shadow-lg group">
            <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center mb-6 group-hover:bg-purple-500/30">
              <CurrencyDollarIcon className="w-6 h-6 text-purple-400" />
            </div>
            <h3 className="text-xl font-bold mb-3 text-white">Financial Forecasting</h3>
            <p className="text-gray-400 leading-relaxed">
              Predict savings growth, debt payoff timelines, and how financial decisions impact your goals.
            </p>
          </div>
        </div>

        {/* Call to Action */}
        <div className="mt-16">
          <a
            href="/home"
            className="inline-block px-8 py-4 bg-[#05b310] text-white text-lg rounded-full shadow-lg hover:shadow-green-500/25 hover:bg-green-600 transition-all duration-300 font-medium transform hover:scale-105"
          >
            Try MoneyMentor Now
          </a>
        </div>
      </div>
    </div>
  );
}

export default function FeaturesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white">
      <Header />
      <FeaturesContent />
      <Footer />
    </div>
  );ss
}

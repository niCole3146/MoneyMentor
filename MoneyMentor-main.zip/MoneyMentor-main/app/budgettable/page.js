// src/BudgetDashboard.js
"use client"
import React, { useState, useMemo } from 'react';
import { useTable } from 'react-table';
import styled from 'styled-components';
import { Pie } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';

// Register chart.js components
ChartJS.register(ArcElement, Tooltip, Legend);

// Styled components for green and white theme
const Container = styled.div`
  background-color: #f0f0f0;
  padding: 20px;
`;

const TableWrapper = styled.div`
  background-color: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-bottom: 30px;
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
`;

const Th = styled.th`
  background-color: #4CAF50;
  color: white;
  padding: 10px;
`;

const Td = styled.td`
  padding: 10px;
  border: 1px solid #ddd;
  color: black;  /* Font color inside table set to black */
`;

const Input = styled.input`
  border: none;
  padding: 5px;
  width: 100%;
  box-sizing: border-box;
`;

const BudgetDashboard = () => {
  const [expenses, setExpenses] = useState([
    { category: 'Groceries', amount: 150 },
    { category: 'Rent', amount: 1200 },
    { category: 'Utilities', amount: 300 },
    { category: 'Entertainment', amount: 100 },
  ]);

  const [income, setIncome] = useState([
    { category: 'Salary', amount: 3000 },
    { category: 'Freelance', amount: 500 },
  ]);

  const handleInputChange = (e, index, column, tableType) => {
    const updatedData = tableType === 'expenses' ? [...expenses] : [...income];
    updatedData[index][column] = e.target.value;

    if (tableType === 'expenses') {
      setExpenses(updatedData);
    } else {
      setIncome(updatedData);
    }
  };

  // Define the columns for react-table
  const columns = useMemo(
    () => [
      {
        Header: 'Category',
        accessor: 'category',
      },
      {
        Header: 'Amount ($)',
        accessor: 'amount',
        Cell: ({ row, column, table }) => {
          return (
            <Input
              value={row.values[column.id]}
              onChange={(e) => handleInputChange(e, row.index, column.id, table)}
            />
          );
        },
      },
    ],
    [expenses, income]
  );

  // Expenses table
  const { getTableProps: getExpensesTableProps, getTableBodyProps: getExpensesTableBodyProps, headerGroups: expensesHeaderGroups, rows: expensesRows, prepareRow: prepareExpensesRow } = useTable({
    columns,
    data: expenses,
  });

  // Income table
  const { getTableProps: getIncomeTableProps, getTableBodyProps: getIncomeTableBodyProps, headerGroups: incomeHeaderGroups, rows: incomeRows, prepareRow: prepareIncomeRow } = useTable({
    columns,
    data: income,
  });

  // Pie Chart Data
  const pieChartData = (data) => ({
    labels: data.map((item) => item.category),
    datasets: [
      {
        data: data.map((item) => parseFloat(item.amount)),
        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4CAF50', '#FF9F40'],
        hoverBackgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4CAF50', '#FF9F40'],
      },
    ],
  });

  return (
    <Container>
      <h1 style={{ color: '#4CAF50' }}>Budget Dashboard</h1>
      
      {/* Expenses Table */}
      <h2 style={{ color: '#4CAF50' }}>Expenses</h2>
      <TableWrapper>
        <Table {...getExpensesTableProps()}>
          <thead>
            {expensesHeaderGroups.map(headerGroup => (
              <tr {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map(column => (
                  <Th {...column.getHeaderProps()}>{column.render('Header')}</Th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody {...getExpensesTableBodyProps()}>
            {expensesRows.map(row => {
              prepareExpensesRow(row);
              return (
                <tr {...row.getRowProps()}>
                  {row.cells.map(cell => (
                    <Td {...cell.getCellProps()}>{cell.render('Cell')}</Td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </Table>
      </TableWrapper>

      {/* Income Table */}
      <h2 style={{ color: '#4CAF50' }}>Income</h2>
      <TableWrapper>
        <Table {...getIncomeTableProps()}>
          <thead>
            {incomeHeaderGroups.map(headerGroup => (
              <tr {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map(column => (
                  <Th {...column.getHeaderProps()}>{column.render('Header')}</Th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody {...getIncomeTableBodyProps()}>
            {incomeRows.map(row => {
              prepareIncomeRow(row);
              return (
                <tr {...row.getRowProps()}>
                  {row.cells.map(cell => (
                    <Td {...cell.getCellProps()}>{cell.render('Cell')}</Td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </Table>
      </TableWrapper>

      {/* Pie Chart for Expenses */}
      <div style={{ width: '50%', margin: '0 auto' }}>
        <h2 style={{ textAlign: 'center' }}>Expenses Distribution</h2>
        <Pie data={pieChartData(expenses)} />
      </div>

      {/* Pie Chart for Income */}
      <div style={{ width: '50%', margin: '0 auto' }}>
        <h2 style={{ textAlign: 'center' }}>Income Distribution</h2>
        <Pie data={pieChartData(income)} />
      </div>
    </Container>
  );
};

export default BudgetDashboard;

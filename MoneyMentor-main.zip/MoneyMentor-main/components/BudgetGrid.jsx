'use client';

import { useSession } from 'next-auth/react';
import { useState, useEffect } from 'react';

export default function BudgetGrid({ budget }) {
  const { data: session } = useSession();
  const [budgetItems, setBudgetItems] = useState([]);

  useEffect(() => {
    if (Array.isArray(budget)) {
      setBudgetItems(budget);
    }
  }, [budget]);

  const handleChange = (index, field, value) => {
    const updated = [...budgetItems];
    updated[index][field] = value;
    setBudgetItems(updated);
  };

  const addNewItem = () => {
    setBudgetItems([
      ...budgetItems,
      { category: '', amount: '' }
    ]);
  };

  if (!budgetItems || budgetItems.length === 0) {
    return (
      <div className="text-white">
        No budget data available.
        <button
          onClick={addNewItem}
          className="mt-4 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
        >
          Add Budget Item
        </button>
      </div>
    );
  }

  return (
    <div>
      <div className="grid grid-cols-2 gap-4 mb-6">
        {budgetItems.map((item, index) => (
          <div
            key={index}
            className="bg-gray-800/50 p-4 rounded-xl border border-white/10 flex flex-col space-y-2"
          >
            <input
              type="text"
              value={item.category}
              onChange={(e) => handleChange(index, 'category', e.target.value)}
              placeholder="Category"
              className="bg-gray-700 text-white text-xl font-semibold px-3 py-2 rounded-md outline-none focus:ring-2 focus:ring-green-400"
            />
            <input
              type="number"
              value={item.amount}
              onChange={(e) => handleChange(index, 'amount', e.target.value)}
              placeholder="Amount"
              className="bg-gray-700 text-white px-3 py-2 rounded-md outline-none focus:ring-2 focus:ring-green-400"
            />
          </div>
        ))}
      </div>
      <button
        onClick={addNewItem}
        className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700"
      >
        Add Budget Item
      </button>
    </div>
  );
}

/*
'use client';

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { User, Settings, LogOut, ChevronDown } from "lucide-react";
import { signOut } from "next-auth/react";  // Import signOut from next-auth/react

export default function Header({ userName = "User"}) {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  //const userName = "John Doe"; // This should come from your auth context
  const handleSignOut = async () => {
    await signOut({ redirect: false }); // Prevent auto redirect
    window.location.href = "/api/auth/logout"; // Redirect to Auth0 logout endpoint
  };
 
  return (
    <div className="header flex flex-row justify-between items-center p-6 fixed top-0 w-full z-10">
      <Link href="/" className="logo-container flex items-center gap-3 group">
        <Image
          src="/MoneyMentorColors.png"
          alt="Logo"
          className="logo-image transition-transform duration-300 group-hover:scale-110"
          width={50}
          height={50}
        />
        <span className="logo-text text-xl font-bold text-white tracking-tight">
          MoneyMentor
        </span>
      </Link>
      <div className="flex items-center gap-6">
        <Link href="/home" className="text-white/80 hover:text-white font-medium transition-colors hidden md:block">
          Dashboard
        </Link>
        <Link href="/budget" className="text-white/80 hover:text-white font-medium transition-colors hidden md:block">
          Budget
        </Link>
        <Link href="/chatbot" className="text-white/80 hover:text-white font-medium transition-colors hidden md:block">
          Chat
        </Link>
        
        <div className="relative">
          <button 
            onClick={() => setIsProfileOpen(!isProfileOpen)}
            className="flex items-center gap-2 text-white/80 hover:text-white transition-colors"
          >

            <div className="w-8 h-8 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center hover:bg-white/20 transition-colors">
              <User className="w-5 h-5 text-white/90" />
            </div>
            <span className="hidden md:block font-medium">{userName}</span>
            <ChevronDown className="w-4 h-4" />
          </button>
          
          {isProfileOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-gray-800/95 backdrop-blur-sm rounded-lg shadow-lg py-2 z-20 border border-white/10">
              <Link 
                href="/settings" 
                className="flex items-center gap-2 px-4 py-2 text-white/80 hover:bg-white/10 hover:text-white transition-colors"
              >
                <Settings className="w-4 h-4" />
                <span>Settings</span>
              </Link>
              <button
                onClick={handleSignOut}
                className="flex items-center gap-2 px-4 py-2 text-white/80 hover:bg-white/10 hover:text-white transition-colors w-full"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
*/
'use client';

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { User, Settings, LogOut, ChevronDown } from "lucide-react";
import { useSession, signOut } from "next-auth/react";

export default function Header({ userName = "User", userImage }) {
  const { data: session, status } = useSession();

  const [isProfileOpen, setIsProfileOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut({ redirect: false });
    window.location.href = "/api/auth/logout";
  };

  const handleSignUpClick = () => {
    signIn("auth0", { callbackUrl: "/home" }); 
  };

  return (
    <div className="header flex flex-row justify-between items-center p-6 fixed top-0 w-full z-10">
      <Link href="/" className="logo-container flex items-center gap-3 group">
        <Image
          src="/MoneyMentorColors.png"
          alt="Logo"
          className="logo-image transition-transform duration-300 group-hover:scale-110"
          width={50}
          height={50}
        />
        <span className="logo-text text-xl font-bold text-white tracking-tight">
          MoneyMentor
        </span>
      </Link>
    
      <div className="flex items-center gap-6">
      <div className="flex items-center gap-6">
  {!session ? (
    <>
      <button
        className="text-gray-300 hover:text-white transition-colors hidden md:block bg-transparent border-0 p-0"
        onClick={handleSignUpClick}
      >
        Log In
      </button>
      <button
        className="signup-button bg-gradient-to-r from-blue-500 to-blue-600 text-white px-6 py-2.5 rounded-full shadow-lg hover:shadow-blue-500/25 hover:from-blue-600 hover:to-blue-700 transition-all duration-300 font-medium"
        onClick={handleSignUpClick}
      >
        Sign Up Free
      </button>
    </>
  ) : (
    <>
      <Link
        href="/home"
        className="text-white/80 hover:text-white font-medium transition-colors hidden md:block"
      >
        Dashboard
      </Link>
      <Link
        href="/budget"
        className="text-white/80 hover:text-white font-medium transition-colors hidden md:block"
      >
        Budget
      </Link>
      <Link
        href="/chatbot"
        className="text-white/80 hover:text-white font-medium transition-colors hidden md:block"
      >
        Chat
      </Link>

      {/* Profile Dropdown */}
      <div className="relative">
        <button
          onClick={() => setIsProfileOpen(!isProfileOpen)}
          className="flex items-center gap-2 text-white/80 hover:text-white transition-colors"
        >
          {userImage ? (
            <Image
              src={userImage}
              alt="Profile"
              width={32}
              height={32}
              className="rounded-full object-cover border border-white/20 hover:border-white transition-colors"
            />
          ) : (
            <div className="w-8 h-8 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center hover:bg-white/20 transition-colors">
              <User className="w-5 h-5 text-white/90" />
            </div>
          )}
          <span className="hidden md:block font-medium">{userName}</span>
          <ChevronDown className="w-4 h-4" />
        </button>

        {isProfileOpen && (
          <div className="absolute right-0 mt-2 w-48 bg-gray-800/95 backdrop-blur-sm rounded-lg shadow-lg py-2 z-20 border border-white/10">
            <Link
              href="/settings"
              className="flex items-center gap-2 px-4 py-2 text-white/80 hover:bg-white/10 hover:text-white transition-colors"
            >
              <Settings className="w-4 h-4" />
              <span>Settings</span>
            </Link>
            <button
              onClick={handleSignOut}
              className="flex items-center gap-2 px-4 py-2 text-white/80 hover:bg-white/10 hover:text-white transition-colors w-full"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
          </div>
        )}
      </div>
    </>
  )}
</div>
      </div>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { usePlaidLink } from 'react-plaid-link';

export default function PlaidLink({ onSuccess }) {
  const [linkToken, setLinkToken] = useState(null);

  useEffect(() => {
    const getLinkToken = async () => {
      try {
        const response = await fetch('/api/plaid/create-link-token', {
          method: 'POST',
        });
        const data = await response.json();
        setLinkToken(data.linkToken);
      } catch (error) {
        console.error('Error getting link token:', error);
      }
    };

    getLinkToken();
  }, []);

  const { open, ready } = usePlaidLink(
    linkToken
      ? {
          token: linkToken,
          onSuccess: async (public_token, metadata) => {
            try {
              const response = await fetch('/api/plaid/exchange-token', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ public_token }),
              });

              if (!response.ok) throw new Error('Failed to exchange token');

              const data = await response.json();
              onSuccess(data.accessToken, metadata);
            } catch (error) {
              console.error('Error exchanging token:', error);
            }
          },
          onExit: (err) => {
            if (err) console.error('Plaid Link error:', err);
          },
        }
      : {} // ✅ Safe fallback config while loading
  );

  
  return (
    <button
      onClick={() => open()}
      disabled={!ready}
      className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
    >
      {ready ? 'Connect Your Bank' : 'Loading...'}
    </button>
  );
} 
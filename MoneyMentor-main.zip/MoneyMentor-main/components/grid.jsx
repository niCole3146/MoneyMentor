'use client';
import React, { useMemo, useRef, useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import {
  ClientSideRowModelApiModule,
  ClientSideRowModelModule,
  CheckboxEditorModule,
  ModuleRegistry,
  NumberEditorModule,
  TextEditorModule,
  ValidationModule,
} from "ag-grid-community";
import { themeQuartz } from 'ag-grid-community';
import Papa from 'papaparse'; // Importing papaparse

ModuleRegistry.registerModules([
  NumberEditorModule,
  TextEditorModule,
  ClientSideRowModelApiModule,
  ClientSideRowModelModule,
  ValidationModule,
  CheckboxEditorModule,
]);

// run npm install ag-grid-react ag-grid-community papaparse !


export default function Grid() {
  const gridRef = useRef(null);

  const myTheme = themeQuartz.withParams({
    backgroundColor: "#000000",
    browserColorScheme: "dark",
    chromeBackgroundColor: {
      ref: "foregroundColor",
      mix: 0.07,
      onto: "backgroundColor"
    },
    foregroundColor: "#FFF",
    headerFontSize: 14
  });

  const [rowData, setRowData] = useState([
    { date: "3/5/25", description: "car", amount: 6000, category: "expense" },
    { date: "February", description: "netflix", amount: 7.89, category: "deposit" },
  ]);

  const [columnDefs, setColumnDefs] = useState([
    { field: "date" },
    { field: "description" },
    { field: "amount" },
    { field: "category" },
  ]);

  const [newCategory, setNewCategory] = useState("");

  const defaultColDef = useMemo(() => ({
    flex: 1,
    editable: true,
  }), []);

  const addCategory = () => {
    const newField = newCategory.trim();
    if (!newField) return;

    if (columnDefs.some(col => col.field === newField)) {
      alert("This category already exists!");
      return;
    }

    setColumnDefs(prev => [...prev, { field: newField }]);
    setRowData(prev => prev.map(row => ({ ...row, [newField]: "" })));
    setNewCategory("");
  };

  const addRow = () => {
    const newRow = columnDefs.reduce((acc, col) => {
      acc[col.field] = "";
      return acc;
    }, {});
    setRowData(prev => [...prev, newRow]);
  };

  // Function to handle file upload and CSV parsing (going to move to upload spreadsheet soon)
  const handleCSVUpload = (event) => {
    const file = event.target.files[0]; // Get the uploaded file
    if (!file) return;

    Papa.parse(file, {
      complete: (result) => {
        // Parse the CSV data and update the grid's rowData
        const columns = result.data[0]; // first row is headers
        const rows = result.data.slice(1); // rest are the data rows

        // Update column definitions based on CSV header
        const newColumnDefs = columns.map(col => ({ field: col }));

        setColumnDefs(newColumnDefs);
        setRowData(rows.map(row => {
          return columns.reduce((acc, col, index) => {
            acc[col] = row[index];
            return acc;
          }, {});
        }));
      },
      header: false, // Indicating that CSV does not contain a header row by default
    });
  };

  return (
    <div style={{ padding: '1rem' }}>
      <div
  style={{
    display: 'flex',
    flexWrap: 'wrap',
    alignItems: 'center',
    gap: '1rem',
    marginBottom: '1.5rem',
  }}
>
  <label
  className="bg-blue-500"
    style={{
      padding: '0.75rem 1rem',
      color: '#fff',
      borderRadius: '6px',
      cursor: 'pointer',
    }}
  >
    Choose File
    <input
      type="file"
      accept=".csv"
      onChange={handleCSVUpload}
      style={{ display: 'none' }}
    />
  </label>

  <input
    type="text"
    value={newCategory}
    onChange={(e) => setNewCategory(e.target.value)}
    placeholder="type a new category..."
    style={{
      padding: '0.75rem',
      fontSize: '1rem',
      borderRadius: '6px',
      border: '1px solid #ccc',
      flexGrow: 1,
      minWidth: '200px',
    }}
  />

  <button
    className="bg-green-500"
    onClick={addCategory}
    style={{
      padding: '0.75rem 1.25rem',
      color: '#000',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
    }}
  >
    ➕ Add Category
  </button>

  <button
    className="bg-green-500"
    onClick={addRow}
    style={{
      padding: '0.75rem 1.25rem',
      color: '#000',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
    }}
  >
    ➕ Add Row
  </button>
</div>


      <div style={{ height: 400, width: '100%' }}>
        <AgGridReact
          ref={gridRef}
          rowData={rowData}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          animateRows={true}
          theme={myTheme}
        />
      </div>
    </div>
  );
}